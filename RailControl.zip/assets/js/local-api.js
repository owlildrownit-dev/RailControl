const api={
config:API_CONFIG,
async list(collection){await wait();return structuredClone(state.db[collection]||[])},
async get(collection,id){await wait();return structuredClone((state.db[collection]||[]).find(x=>x.id===Number(id))||null)},
async create(collection,payload){await wait();const item={id:nextId(collection),...payload};state.db[collection].push(item);saveDB();return structuredClone(item)},
async update(collection,id,payload){await wait();const index=state.db[collection].findIndex(x=>x.id===Number(id));if(index<0)throw new Error('Запись не найдена');state.db[collection][index]={...state.db[collection][index],...payload};saveDB();return structuredClone(state.db[collection][index])},
async remove(collection,id){await wait();const index=state.db[collection].findIndex(x=>x.id===Number(id));if(index<0)throw new Error('Запись не найдена');const [item]=state.db[collection].splice(index,1);saveDB();return structuredClone(item)},
auth:{async login(email,password){await wait(120);const normalizedEmail=String(email).trim().toLowerCase();const submittedPassword=String(password);const user=state.db.users.find(u=>String(u.email).trim().toLowerCase()===normalizedEmail&&String(u.password)===submittedPassword);if(!user)throw new Error('Неверный email или пароль');const{password:removedPassword,...safeUser}=user;return structuredClone(safeUser)}}
};
