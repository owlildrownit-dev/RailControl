const DB_KEY='railcontrol_expanded_v2';
const SESSION_KEY='railcontrol_expanded_session_v2';
const API_CONFIG={baseURL:'local://railcontrol/api',timeout:5000,version:'1.0'};
const roles={PASSENGER:'Пассажир',OPERATOR:'Оператор',ADMIN:'Администратор'};
const labels={
tripStatus:{PLANNED:'Запланирован',BOARDING:'Посадка',DELAYED:'Задерживается',ARRIVED:'Прибыл',DEPARTED:'Отправлен',CANCELLED:'Отменён'},
bookingStatus:{RESERVED:'Забронирован',ISSUED:'Оформлен',CANCELLED:'Отменён',REFUNDED:'Возвращён'},
taskStatus:{TODO:'Новая',IN_PROGRESS:'В работе',DONE:'Выполнена',OVERDUE:'Просрочена'},
priority:{LOW:'Низкий',MEDIUM:'Средний',HIGH:'Высокий'},
resourceStatus:{ACTIVE:'Доступен',MAINTENANCE:'Обслуживание',CLOSED:'Закрыт'},
employeeStatus:{WORKING:'Работает',VACATION:'Отпуск',SICK:'Больничный',DISMISSED:'Уволен'},
severity:{INFO:'Информация',WARNING:'Предупреждение',CRITICAL:'Критическое'},
operation:{RESERVE:'Бронирование',ISSUE:'Оформление билета',CANCEL:'Отмена',REFUND:'Возврат'}
};
const state={db:null,user:null,page:'dashboard',directoryTab:'stations',dispatchTab:'trips',ticketTab:'search',taskView:'board',search:'',ticketSearch:{from:'',to:'',date:''},selectedSeat:null};
function nowISO(){return new Date().toISOString()}
function dateShift(days,hour=10,minute=0){const d=new Date();d.setDate(d.getDate()+days);d.setHours(hour,minute,0,0);return d}
function dateOnly(d){const x=new Date(d);return x.toISOString().slice(0,10)}
function timeOnly(d){const x=new Date(d);return x.toTimeString().slice(0,5)}
function seedData(){
const stations=[
{id:1,code:'MSK',name:'Москва-Пассажирская',city:'Москва',timezone:'Europe/Moscow',type:'Вокзал'},
{id:2,code:'SPB',name:'Санкт-Петербург-Главный',city:'Санкт-Петербург',timezone:'Europe/Moscow',type:'Вокзал'},
{id:3,code:'YAR',name:'Ярославль-Главный',city:'Ярославль',timezone:'Europe/Moscow',type:'Станция'},
{id:4,code:'NNG',name:'Нижний Новгород-Московский',city:'Нижний Новгород',timezone:'Europe/Moscow',type:'Вокзал'},
{id:5,code:'KZN',name:'Казань-Пассажирская',city:'Казань',timezone:'Europe/Moscow',type:'Вокзал'},
{id:6,code:'VLD',name:'Владимир',city:'Владимир',timezone:'Europe/Moscow',type:'Станция'}
];
const platforms=[
{id:1,stationId:1,name:'Платформа 1',type:'Высокая',status:'ACTIVE'},
{id:2,stationId:1,name:'Платформа 2',type:'Высокая',status:'ACTIVE'},
{id:3,stationId:1,name:'Платформа 3',type:'Низкая',status:'MAINTENANCE'},
{id:4,stationId:1,name:'Платформа 4',type:'Высокая',status:'ACTIVE'}
];
const tracks=[
{id:1,stationId:1,platformId:1,number:'1',status:'ACTIVE'},
{id:2,stationId:1,platformId:1,number:'2',status:'ACTIVE'},
{id:3,stationId:1,platformId:2,number:'3',status:'ACTIVE'},
{id:4,stationId:1,platformId:2,number:'4',status:'ACTIVE'},
{id:5,stationId:1,platformId:3,number:'5',status:'MAINTENANCE'},
{id:6,stationId:1,platformId:3,number:'6',status:'ACTIVE'},
{id:7,stationId:1,platformId:4,number:'7',status:'ACTIVE'},
{id:8,stationId:1,platformId:4,number:'8',status:'ACTIVE'}
];
const trains=[
{id:1,number:'002А',name:'Красная стрела',type:'Скорый',operator:'РЖД'},
{id:2,number:'104В',name:'Москва — Ярославль',type:'Скорый',operator:'ФПК'},
{id:3,number:'019С',name:'Премиум',type:'Фирменный',operator:'ФПК'},
{id:4,number:'078М',name:'Стриж',type:'Скоростной',operator:'РЖД'},
{id:5,number:'126Э',name:'Поволжье',type:'Скорый',operator:'ФПК'}
];
const carriages=[];const seats=[];let carriageId=1,seatId=1;
trains.forEach((t,ti)=>{for(let c=1;c<=3;c++){const type=c===1?'СВ':c===2?'Купе':'Плацкарт';const count=type==='СВ'?18:type==='Купе'?36:54;carriages.push({id:carriageId,trainId:t.id,number:String(c).padStart(2,'0'),type,className:type,seatsCount:count});for(let s=1;s<=Math.min(count,24);s++){seats.push({id:seatId++,carriageId,number:String(s),type:s%2?'Нижнее':'Верхнее',coefficient:type==='СВ'?2:type==='Купе'?1.45:1,status:'ACTIVE'});}carriageId++;}});
const routes=[
{id:1,name:'Москва — Санкт-Петербург',originStationId:1,destinationStationId:2,durationMin:230,stops:'Тверь, Бологое'},
{id:2,name:'Москва — Ярославль',originStationId:1,destinationStationId:3,durationMin:210,stops:'Александров, Ростов Великий'},
{id:3,name:'Казань — Москва',originStationId:5,destinationStationId:1,durationMin:720,stops:'Канаш, Арзамас'},
{id:4,name:'Москва — Нижний Новгород',originStationId:1,destinationStationId:4,durationMin:235,stops:'Владимир, Дзержинск'},
{id:5,name:'Москва — Владимир',originStationId:1,destinationStationId:6,durationMin:120,stops:'Орехово-Зуево'}
];
const trips=[
{id:1,routeId:1,trainId:1,date:dateOnly(dateShift(0)),departure:'10:30',arrival:'14:20',platformId:2,trackId:4,status:'BOARDING',delayMinutes:0,basePrice:3200},
{id:2,routeId:2,trainId:2,date:dateOnly(dateShift(0)),departure:'12:15',arrival:'15:45',platformId:1,trackId:2,status:'PLANNED',delayMinutes:0,basePrice:1650},
{id:3,routeId:3,trainId:3,date:dateOnly(dateShift(0)),departure:'13:05',arrival:'13:05',platformId:3,trackId:6,status:'DELAYED',delayMinutes:25,basePrice:2800},
{id:4,routeId:4,trainId:4,date:dateOnly(dateShift(0)),departure:'15:40',arrival:'19:35',platformId:4,trackId:8,status:'PLANNED',delayMinutes:0,basePrice:2450},
{id:5,routeId:5,trainId:5,date:dateOnly(dateShift(1)),departure:'18:05',arrival:'20:05',platformId:1,trackId:1,status:'PLANNED',delayMinutes:0,basePrice:1200},
{id:6,routeId:1,trainId:3,date:dateOnly(dateShift(0)),departure:'10:45',arrival:'15:00',platformId:2,trackId:4,status:'PLANNED',delayMinutes:0,basePrice:2900}
];
const employees=[
{id:1,fullName:'Смирнов Алексей Викторович',position:'Начальник вокзала',department:'Администрация',phone:'+7 900 100-10-01',email:'smirnov@station.local',status:'WORKING'},
{id:2,fullName:'Иванова Мария Сергеевна',position:'Диспетчер',department:'Диспетчерская',phone:'+7 900 100-10-02',email:'ivanova@station.local',status:'WORKING'},
{id:3,fullName:'Петров Илья Андреевич',position:'Кассир',department:'Билетные кассы',phone:'+7 900 100-10-03',email:'petrov@station.local',status:'WORKING'},
{id:4,fullName:'Орлова Елена Павловна',position:'Инженер',department:'Техническая служба',phone:'+7 900 100-10-04',email:'orlova@station.local',status:'VACATION'}
];
const users=[
{id:1,fullName:'Администратор системы',email:'admin@station.local',password:'Admin123!',role:'ADMIN',employeeId:1},
{id:2,fullName:'Оператор вокзала',email:'operator@station.local',password:'Operator123!',role:'OPERATOR',employeeId:2},
{id:3,fullName:'Демонстрационный пассажир',email:'passenger@station.local',password:'Passenger123!',role:'PASSENGER',employeeId:null}
];
const tasks=[
{id:1,title:'Проверить конфликт путей',description:'Переназначить путь для рейса 019С или 002А.',employeeId:2,priority:'HIGH',status:'IN_PROGRESS',dueDate:dateOnly(dateShift(0)),createdAt:nowISO()},
{id:2,title:'Осмотр платформы 3',description:'Зафиксировать результаты технического осмотра.',employeeId:4,priority:'MEDIUM',status:'TODO',dueDate:dateOnly(dateShift(1)),createdAt:nowISO()},
{id:3,title:'Подготовить суточный отчёт',description:'Сформировать статистику отправлений и задержек.',employeeId:1,priority:'LOW',status:'DONE',dueDate:dateOnly(dateShift(-1)),createdAt:nowISO()}
];
const bookings=[{id:1,userId:3,tripId:2,passengerName:'Демонстрационный пассажир',seatId:seats.find(s=>s.carriageId===4&&s.number==='12').id,status:'ISSUED',amount:2392.5,ticketNumber:'RC-2026-0001',createdAt:nowISO()}];
const operations=[{id:1,bookingId:1,type:'RESERVE',amount:0,performedBy:'Демонстрационный пассажир',createdAt:nowISO()},{id:2,bookingId:1,type:'ISSUE',amount:2392.5,performedBy:'Демонстрационный пассажир',createdAt:nowISO()}];
const notifications=[
{id:1,title:'Задержка поезда № 019С',message:'Ожидаемая задержка составляет 25 минут.',audience:'ALL',severity:'WARNING',createdAt:nowISO(),readBy:[]},
{id:2,title:'Технические работы',message:'Платформа 3 частично закрыта для обслуживания.',audience:'STAFF',severity:'INFO',createdAt:nowISO(),readBy:[]}
];
const audit=[{id:1,user:'Система',action:'Создана автономная база данных RailControl',createdAt:nowISO()}];
return{users,stations,platforms,tracks,trains,carriages,seats,routes,trips,bookings,operations,employees,tasks,notifications,audit,counters:{users:4,stations:7,platforms:5,tracks:9,trains:6,carriages:carriageId,seats:seatId,routes:6,trips:7,bookings:2,operations:3,employees:5,tasks:4,notifications:3,audit:2}};
}
function loadDB(){try{const raw=localStorage.getItem(DB_KEY);state.db=raw?JSON.parse(raw):seedData()}catch(e){state.db=seedData()}saveDB()}
function saveDB(){localStorage.setItem(DB_KEY,JSON.stringify(state.db))}
function nextId(collection){const id=state.db.counters[collection]||1;state.db.counters[collection]=id+1;return id}
function wait(ms=70){return new Promise(r=>setTimeout(r,ms))}
